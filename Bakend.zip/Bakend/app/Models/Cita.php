<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cita extends Model
{
    use HasFactory;

       // Relación de uno a muchos
    // Una cárcel le pertenece a un pabellón
    public function paciente()
    {
        return $this->belongsTo(Paciente::class);
    }

    // Relación de uno a muchos
    // Un pabellón puede tener muchas cárceles
    public function servicios()
    {
        return $this->hasMany(Servicio::class);
    }


}
