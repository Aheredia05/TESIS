<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Servicio extends Model
{
    use HasFactory;

  
    // Relación de muchos a muchos
    // Una cárcel puede tener muchos usuarios
    public function users()
    {
        return $this->belongsToMany(User::class)->withTimestamps();
    }




    
       // Relación de uno a muchos
    // Una cita le pertenece a un servicio
    public function servicio()
    {
        return $this->belongsTo(Servicio::class);
    }


    /*
    // Relación polimórfica uno a uno
    // Una cárcel pueden tener una imagen
    public function image()
    {
        return $this->morphOne(Image::class,'imageable');
    }
    */
}
